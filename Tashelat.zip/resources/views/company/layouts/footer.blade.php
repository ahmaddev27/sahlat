<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">
             &copy; {{date('Y')}}<span class="d-none d-sm-inline-block">, {{trans('main.footer')}} {{setting('name')}}</span></span>

    </p>
</footer>
