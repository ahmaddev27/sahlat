<?php

return [
    'title'=>'العنوان',
    'new-service'=>'خدمة جديدة',
    'action'=>'خيارات',
    'edit-service'=>'تعديل الخدمة',



];
