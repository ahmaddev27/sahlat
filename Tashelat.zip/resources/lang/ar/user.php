<?php

return [
    'name'=>'الاسم',
    'email'=>'البريد الالكتروني',
    'password'=>'كلمة المرور',
    'save'=>'حفظ',
    'new-user'=>'اضافة مستخدم جديدة',
    'edit-user'=>'تعديل مستخدم ',
    'action'=>'خيارات',
    'workers'=>'شغالات',

    'phone'=>'رقم الهاتف',
    'address'=>'العنوان',
    'avatar'=>'الصورة',
    'edit'=>'تعديل',
    'location'=>'المدينة',
    'gender'=>'الجنس',
    'number_id'=>'رقم الهوية',
    'male'=>'ذكر',
    'female'=>'انثى',
    'select-city'=>'اختار المدينة',
'status'=>'الحالة',

];


