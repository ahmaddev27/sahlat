
<?php

return [
    'personal' => 'المعلومات الشخصية',
    'password' => 'تغيير كلمة المرور',
    'name' => 'الاسم',
    'email' => 'البريد الإلكتروني',
    'phone' => 'الهاتف',
    'new-password' => 'كلمة مرور جديدة',
    'conf-password' => 'تأكيد كلمة المرور',
];
