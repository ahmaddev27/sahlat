<?php

return [
    'dashboard'=>'لوحة التحكم',
    'settings'=>'الاعدادات',
    'companies'=>'الشركات',
    'users'=>'المستخدمين',
    'housekeepers'=>'الشغالات',
    'housekeepers-orders'=>'طلبات الشغالات',
    'housekeepers-HourlyOrders'=>'الطلبات  بالساعة',
    'violations'=>'المخالفات',
    'violations-orders'=>'طلبات المخالفات',
    'orders-completed'=>'طلبات مكتملة',
    'orders-cancelled'=>'طلبات ملغية',
    'assurances'=>'الضمانات',
    'profile'=>'البروفايل',
    'assurances-orders'=>'طلبات الضمانات',
    'payments'=>'المدفوعات',
    'services'=>'الخدمات',
    'contacts'=>'التواصل',
    'housekeepers_hourly'=>'طلبات الشغالات بالساعة',



];


