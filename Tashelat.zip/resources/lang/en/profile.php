
<?php

return [
    'personal' => 'Personal information',
    'password' => 'Change Password',
    'name' => 'Name',
    'email' => 'E-mail',
    'phone' => 'Phone',
    'new-password' => 'New Password',
    'conf-password' => 'Confirm Password',
];
