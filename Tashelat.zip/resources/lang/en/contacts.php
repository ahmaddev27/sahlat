<?php

return [

    'text'=>'Message',
    'title'=>'Title',
    'date'=>'Date',
    'user'=>'user',
    'status'=>'Status',
    'action'=>'Action',
    'view'=>'View',
    'read'=>'Read',
    'not-read'=>'unread',


];


