<?php

return [
    'title'=>'title',
    'avatar'=>'image',
    'status'=>'status',

    'action'=>'options',

    'description'=>'details',
    'details'=>'comments',
    'user'=>'user',
    'price'=>'price',
    'violation'=>'violation',
    'attachments'=>'attachments',
    'no-files'=>'no files',
    'order_id'=>'order number',
    'date'=>'order date',
    'payment'=>'payment status',
    'total'=>'amount',
    'change-status'=>'change status',
    'payment-type'=>'payment method',
    'file'=>'file',
    'type'=>'file type',
    'order-details'=>'order details',
    'name'=>'name',
    'note'=>'notes',
    'phone'=>'phone',
    'value'=>'Violation value',


    'number_id'=>'id number',

    'violation_number'=>'violation number'


];
