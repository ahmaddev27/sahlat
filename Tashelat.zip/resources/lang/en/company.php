<?php

return [
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'save' => 'Save',
    'action' => 'Action',
    'new-company' => 'Add New Company',
    'edit-company' => 'Edit Company',
    'workers' => 'Housekeeper',
    'phone' => 'Phone',
    'address' => 'Address',
    'avatar' => 'Avatar',
    'edit' => 'Edit',
    'experience' => 'Years Of Experience',
    'lat' => 'latitude',
    'long' => 'longitude',
    'bio' => 'Bio',
    'hourly_price'=>'Hourly Price For HouseKeeper',
    'hourly_note'=>'If the company does not hire by the hour, leave it blank.',

];
