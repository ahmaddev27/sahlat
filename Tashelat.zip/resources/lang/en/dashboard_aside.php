<?php

return [

    'dashboard'=>'Dashboard',
    'settings'=>'Settings',
    'companies'=>'Companies',
    'users'=>'Users',
    'housekeepers'=>'Housekeepers',
    'housekeepers-orders'=>'Housekeepers Orders',
    'assurances'=>'Assurance',
    'assurances-orders'=>'Assurance Orders',
    'profile'=>'Profile',
    'orders-completed'=>'Completed Orders',
    'orders-cancelled'=>'Cancelled Orders',

    'violations'=>'Violations',

    'payments'=>'Payments',

    'services'=>'Services',

    'contacts'=>'Contacts',

    'violations-orders'=>'Violations Orders',
    'housekeepers-HourlyOrders'=>'Hourly Orders',
    'housekeepers_hourly'=>'housekeepers Hourly Orders',
];


