<?php

return [
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'save' => 'Save',
    'action' => 'Action',
    'new-user' => 'Add New User',
    'edit-user' => 'Edit User',
    'workers'=>'Housekeeper',
    'phone'=>'Phone',
    'address'=>'Address',
    'avatar'=>'Avatar',
    'edit'=>'Edit',

    'location'=>'City',
    'gender'=>'Gender',
    'male'=>'male',
    'female'=>'female',
    'number_id'=>'ID Number',
    'select-city'=>'Select City',
    'status'=>'Status',

];
