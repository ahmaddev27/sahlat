<?php
return [
    'settings' => 'Settings',
    'info' => 'Site Information',
    'social' => 'Social Media',
    'change' => 'Change',
    'logo' => 'Logo',
    'icon' => 'Icon',
    'email' => 'Email',
    'name' => 'Name',
    'whatsapp' => 'WhatsApp',
    'about' => 'About Us',
    'twitter' => 'Twitter',
    'facebook' => 'Facebook',
    'instagram' => 'Instagram',
    'commission' => 'Commission',
    'banners'=>'Banners',
    'actions'=>'Actions',
    'title'=>'Title',
    'image'=>'Image',
    'status'=>'status',
    'edit-banner'=>'Edit Banner',
    'new-banner'=>'New Banner',
    'policy'=>'Privacy Policy',
    'conditions'=>'Terms and Conditions',



];
