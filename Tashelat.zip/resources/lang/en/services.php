<?php

return [
    'title'=>'Title',
    'new-service'=>'New Service',
    'action'=>'Action',
    'edit-service'=>'Edit Service',



];
